--------------------------------------------------------
--  File created - Wednesday-August-04-2021   
--------------------------------------------------------
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\DROPS.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\TYPES.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\TABLES.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\ACCESSIBLE_SEAT_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\BOOKING_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\BOX_SEAT_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\CUSTOMER_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\CUSTOMER_HISTORY_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\MOVIE_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\NORMAL_SEAT_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\RECLINING_SEAT_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\SEAT_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\SEAT_RESERVATION_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\SHIPPING_OFFERING_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\SHOWTIME_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\TAX_RATES_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\THEATER_DATA_TABLE.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\INDEXES.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\TRIGGERS.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\PROCEDURES.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\CONSTRAINTS.sql
@G:\My Drive\CourseWork\met-cs-dmbi\3-669_DB_Design\TermProject\1-CS669_vshiv_TermProject_bookmytalkies\CS669_BOOKMYTALKIES\REF_CONSTRAINTS.sql
