--------------------------------------------------------
--  DDL for Type SEAT_ROW_LIST
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "CS669"."SEAT_ROW_LIST" IS TABLE OF VARCHAR2(200)

/
--------------------------------------------------------
--  DDL for Type SEAT_ROW_LIST
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "CS669"."SEAT_ROW_LIST" IS TABLE OF VARCHAR2(200)

/
